package com.bridge.pojo;

import java.util.Date;

public class Student {
	private String userName;
	private String passWord;
	private String fName;
	private String lName;
	private String dob;
	private String contactNumber;
	private String eMail;
	
	
	public Student() {
	}
	public Student(String userName, String passWord, String fName, String lName, String dob, String contactNumber,
			String eMail) {
		this.userName = userName;
		this.passWord = passWord;
		this.fName = fName;
		this.lName = lName;
		this.dob = dob;
		this.contactNumber = contactNumber;
		this.eMail = eMail;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	
	
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	@Override
	public String toString() {
		return "Student [userName=" + userName + ", passWord=" + passWord + ", fName=" + fName + ", lName=" + lName
				+ ", dob=" + dob + ", contactNumber=" + contactNumber + ", eMail=" + eMail + "]";
	}
	
	
}
